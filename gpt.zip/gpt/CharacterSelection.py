import pygame
from Scripts.Scene.scenebase import ScreenBase
from Scripts.PlayerCharacter.Naruto.naruto_character import NarutoCharacter
from Scripts.PlayerCharacter.Sasuke.sasuke_character import SasukeCharacter
from Scripts.PlayerCharacter.RockLee.rocklee_character import RockLeeCharacter
from Scripts.PlayerCharacter.Sakura.sakura_character import SakuraCharacter
from Scripts.game_constants import GameConstants
class CharacterSelectionScene(ScreenBase):
    def __init__(self, screen):
        super().__init__(screen)
        self.font = pygame.font.Font(None, 50)
        self.characters = [
            ("Naruto", NarutoCharacter),
            ("Sasuke", SasukeCharacter),
            ("RockLee", RockLeeCharacter),
            ("Sakura", SakuraCharacter),
        ]
        self.character_images = [
            pygame.image.load("Assets/AvaCha/naruto.png"),
            pygame.image.load("Assets/AvaCha/sasuke.png"),
            pygame.image.load("Assets/AvaCha/rocklee.png"),
            pygame.image.load("Assets/AvaCha/sakura.png"),
        ]
        self.selected_character = None
        self.current_player = 1
        self.selected_characters = {}

    def handle_events(self, events):
        for event in events:
            if event.type == pygame.QUIT:
                return "QUIT"
            if event.type == pygame.MOUSEBUTTONDOWN and event.button == 1:  # Click chuột trái
                for idx, char_image in enumerate(self.character_images):
                    rect = pygame.Rect(
                        GameConstants.SCREEN_WIDTH // 2 - 75 + (idx - 2) * 150, 400, 150, 150
                    )  # Căn giữa và điều chỉnh kích thước
                    if rect.collidepoint(event.pos):
                        self.selected_character = self.characters[idx][1]  # Class nhân vật
                        self.selected_characters[self.current_player] = self.characters[idx][1]
                        if self.current_player == 2:  # Nếu Player 2 chọn xong
                            self.next_scene = "GAME"  # Chuyển đến GameScene
                        else:  # Chuyển sang Player 2
                            self.current_player = 2
                            self.selected_character = None


    def update(self):
        self.screen.fill((0, 0, 0))  # Xóa màn hình

        # Tiêu đề
        title_text = f"Player {self.current_player} chọn nhân vật"
        title_surface = self.font.render(title_text, True, (255, 255, 255))
        self.screen.blit(
            title_surface, (GameConstants.SCREEN_WIDTH // 2 - title_surface.get_width() // 2, 50)
        )

        # Hiển thị nhân vật đã chọn
        if self.current_player == 2 and self.current_player in self.selected_characters:
            chosen_text = f"Player 1 đã chọn: {self.characters[self.selected_characters[1]][0]}"
            chosen_surface = self.font.render(chosen_text, True, (255, 255, 255))
            self.screen.blit(
                chosen_surface,
                (GameConstants.SCREEN_WIDTH // 2 - chosen_surface.get_width() // 2, 150),
            )

        # Vẽ danh sách nhân vật
        for idx, char_image in enumerate(self.character_images):
            rect = pygame.Rect(
                GameConstants.SCREEN_WIDTH // 2 - 75 + (idx - 2) * 150, 400, 150, 150
            )
            self.screen.blit(pygame.transform.scale(char_image, (150, 150)), rect)

        # Hiển thị trạng thái nhân vật được chọn
        if self.selected_character:
            confirm_text = f"Đã chọn: {self.characters[idx][0]}"
            confirm_surface = self.font.render(confirm_text, True, (255, 255, 0))
            self.screen.blit(confirm_surface, (GameConstants.SCREEN_WIDTH // 2 - confirm_surface.get_width() // 2, 300))


    def start(self):
        super().start()
        self.current_player = 1
        self.selected_character = None
        self.selected_characters = {}

    def exit(self):
        super().exit()
